import configParser
import socket
import pickle
from distance_vector import routing_alg
import re
import sys
import select
import time
import random

filename = sys.argv[1]
router, outputs, inputs, table = configParser.parser(filename)


def bind_ports(ports):
    """bind the input ports"""
    sockets = []
    for i in ports:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.bind(('', i))
        sockets.append(sock)
    return sockets


def rip_packet():
    """create RIP packet"""
    command = 2
    version = 2
    dests = table.keys()
    entries = []
    for i in dests:
        next_hop = table[i][0]
        metric = table[i][1]
        entries.append((i, next_hop, metric))
    packet = [command, version, router, entries]

    return packet


def send_packets():
    """send packets"""
    for key in outputs:
        packet = rip_packet()
        entries = packet[3]
        for i in range(len(entries)):   # split horizon poisoned reverse
            if entries[i][1] == key and entries[i][1] != entries[i][0]: # receiving router = next hop but not destination
                entries[i] = (entries[i][0], entries[i][1], 16)
        packet_data = pickle.dumps(packet)
        port = outputs[key][1]
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.sendto(packet_data, ("127.0.0.1", port))


def valid_packet(packet):
    """checks whether the received packet is valid
        drops packet if it is invalid"""
    if packet[0] != 2 or packet[1] != 2:
        return 0
    elif int(packet[2]) not in range(1, 64001):
        return 0
    for entry in packet[3]:
        if entry[0] not in range(1, 64001) or entry[1] not in range(1, 64001):
            return 0
    else:
        return 1


def receive_packets():
    """receive packets """
    global table
    sockets = bind_ports(inputs)
    rlist, wlist, xlist = select.select(sockets, [], [], 1)
    if rlist != []:
        for sock in rlist:
            data, _ = sock.recvfrom(2048)
            output = (pickle.loads(data))
            if valid_packet(output) == 1:
                table = routing_alg(output, table, router)
            else:
                print("Invalid packet, packet dropped")


def rip_protocol():
    """swag"""
    count = 0
    bind_ports(inputs)
    send_packets()
    timeout = 60
    while True:
        count += 1
        #receive_packets()
        if count >= int(random.randint(8, 12)):  # iterate every 5 seconds
            send_packets()
            count = 0
        for rtr in list(table.keys()):
            if table[rtr][3] < timeout:
                table[rtr][3] += 1
            if table[rtr][3] == timeout:  # packet has timed out
                table[rtr][2] = True
                table[rtr][1] = 16
                send_packets()
            if table[rtr][2] is True:  # if flag true and time not set, set garbage time
                table[rtr][4] += 1
            if table[rtr][2] is True and table[rtr][4] >= 40:  # garbage time reached, delete table entry
                del table[rtr]
        receive_packets()
        print(table)

rip_protocol()