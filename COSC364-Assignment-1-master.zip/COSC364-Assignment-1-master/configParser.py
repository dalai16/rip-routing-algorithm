import re
import sys
import time
ROUTERS = []


def parser(filename):
    lines = []
    file = open(filename, 'r')
    for i in file.readlines():
        i = re.split(', | |\n', i)
        lines.append(i)

    if len(lines) < 3:
        print('invalid parameters')
        sys.exit()

    routerId = int(lines[0][1])
    inputPorts = lines[1][1:-1]
    output = lines[2][1:-1]

    for i in range(len(inputPorts)):  # convert to ints
        inputPorts[i] = int(inputPorts[i])

    if routerId not in range(1, 64001):  # checks router is valid range
        print("router-id out of range")  # add to ROUTER global if unique
        sys.exit()
    elif routerId not in ROUTERS:
        ROUTERS.append(routerId)
    else:
        print('router-id not unique')
        sys.exit()

    duplicates = []
    for num in inputPorts:
        if num not in range(1024, 64001):
            print("inputPort invalid range")
            sys.exit()
        if num not in duplicates:
            duplicates.append(int(num))
        else:
            print("duplicate input port number")
            sys.exit()

    portNums = []
    outputMetrics = []
    peerIds = []

    for i in output:
        a, b, c = i.split('-')
        portNums.append(a)
        outputMetrics.append(b)
        peerIds.append(c)

    duplicates2 = []
    for i in portNums:
        if int(i) not in range(1024, 64001):  # valid port range
            print("Port invalid range")
            sys.exit()
        if int(i) not in duplicates2:  # duplicate output ports
            duplicates2.append(i)
        else:
            print("port number already exists")
            sys.exit()

        if int(i) in duplicates:  # duplicate input ports
            print("same input output port")
            sys.exit()

    for i in peerIds:
        if int(i) not in range(1, 64001):  # checks peer ids in range
            print("router-id out of range")
            sys.exit()
    if len(peerIds) != len(set(peerIds)):  # check if peer ids unique
        print("peerIds not unique")

    for value in outputMetrics:
        if int(value) <= 0:
            print("metric invalid range")
            sys.exit()

    table = {}
    rtable = {}
    for i in range(len(peerIds)):
        peerId = int(peerIds[i])
        table[peerId] = int(outputMetrics[i]), int(portNums[i])
        rtable[peerId] = [peerId, int(outputMetrics[i]), False, 0, 0]

    return routerId, table, inputPorts, rtable

#print(parser("router1.txt"))