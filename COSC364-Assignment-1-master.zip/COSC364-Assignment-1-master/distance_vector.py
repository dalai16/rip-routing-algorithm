#table1 = {2: [2, 7, False, 0, 0], 3: [3, 2, False, 0, 0]}
#table2 = {1: [1, 7, False, 0, 0], 3: [3, 3, False, 0, 0]}
#table3 = {2: [2, 3, False, 0, 0], 1: [1, 2, False, 0, 0]}

#packet1 = [2, 2, 3, [(1, 1, 2), (2, 2, 3)]]
table1 = {2: [2, 3, False, 0, 0]}
table2 = {1: [1, 3, False, 0, 0]}
table3 = {2: [2, 5, False, 0, 0]}
packet1 = [2, 2, 1, [(2, 2, 3), (3, 2, 16)]]
import time



def routing_alg(rip_packet, routing_table, router_id):
    dests = routing_table.keys()
    entry_dests = []
    entries = rip_packet[3]
    source = rip_packet[2]

    for i in entries:
        entry_dests.append(i[0])

    if source not in dests:
        for i in range(len(entries)):
            if entries[i][0] == router_id:
                metric = entries[i][2]
                routing_table[source] = [source, metric, False, 0, 0]

    else:
        for i in range(len(entry_dests)):
            if entry_dests[i] != router_id:
                dest_id = entries[i][0]
                metric = routing_table[source][1] + entries[i][2]
                if metric <= 16:
                    if dest_id in dests:
                        if metric <= routing_table[dest_id][1]:
                            routing_table[dest_id] = [source, metric, False, 0, 0]
                    else:
                        routing_table[dest_id] = [source, metric, False, 0, 0]
            else:
                metric = entries[i][2]
                routing_table[source] = [source, metric, False, 0, 0]

    return routing_table


#print(routing_alg(packet1, table2, 2))
